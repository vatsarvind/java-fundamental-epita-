/**
 * 
 */
package fr.epita.logging;

/**
 * @author arvind
 *
 */
public class LogConfiguration {
	private String filePath;

	/**method to get filePath
	 * @return the filePath
	 */
	public String getFilePath() {
		return filePath;
	}

	/**
	 * @param filePath the filePath to set
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	/**
	 * 
	 */
	public LogConfiguration(String filePath) {
		this.filePath = filePath;
	}
	
	

}
